<h2>Data Pelayan</h2>

<?php 
	$datapelayan = $pelayan->tampil_pelayan();
 ?>

 <table class="table table-bordered">
 	<thead>
 		<tr>
 			<th>No</th>
 			<th>Nama</th>
 			<th>Username</th>
 			<th>Aksi</th>
 		</tr>
 	</thead>
 	<tbody>
 		<?php foreach ($datapelayan as $key => $value): ?>	
 		<tr>
 			<td><?php echo $key+=1 ?></td>
 			<td><?php echo $value["nama_pelayan"]; ?></td>
 			<td><?php echo $value["username"]; ?></td>
 			<td>
 				<a href="index.php?halaman=ubahpelayan&id=<?php echo $value['id_pelayan']; ?>" class="btn btn-warning">Ubah</a>
 				<a href="index.php?halaman=hapuspelayan&id=<?php echo $value['id_pelayan']; ?>" class="btn btn-danger">Hapus</a>
 			</td>
 		</tr>
 		<?php endforeach ?>
 	</tbody>
 </table>

 <a href="index.php?halaman=tambahpelayan" class="btn btn-primary">Tambah Data</a>