<?php 

$datakategori = $kategori->tampil_kategori();

// echo "<pre>";
// print_r($datakategori);
// echo "</pre>";
 ?>

<h2>Data Kategori</h2>

<table class="table table-bordered">
	<thead>
		<tr>
			<th>No</th>
			<th>Nama Kategori</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($datakategori as $key => $value): ?>
			
		
		<tr>
			<td><?php echo $key+=1  ?></td>
			<td><?php echo $value["nama_kategori"] ?></td>
			<td>
				<a href="index.php?halaman=ubahkategori&id=<?php echo $value['id_kategori'] ?>" class="btn btn-warning">Ubah</a>
				<a href="index.php?halaman=hapuskategori&id=<?php echo $value['id_kategori'] ?>" class="btn btn-danger">Hapus</a>
			</td>
		</tr>
		<?php endforeach ?>
	</tbody>
</table>

<a href="index.php?halaman=tambahkategori" class="btn btn-primary">Tambah Data</a>