<h2>Selamat Datang di Home Kasir</h2>
<pre><?php print_r($_SESSION); ?></pre>