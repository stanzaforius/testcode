<h2>Data Pesanan</h2>

<?php 

$datapesanan = $pesanan->tampil_pesanan();
 ?>
 <!-- <pre><?php //print_r($datapembelian); ?></pre> -->

 <table class="table table-bordered table-hover table-stripped">
 	<thead>
 		<tr>
 			<th>No pesanan</th>
 			<th>Tanggal</th>
 			<th>Nomor Meja Pelanggan</th>
 			<th>Status</th>
 			<th>Total Pembayaran</th>
 			<th>Aksi</th>
 		</tr>
 	</thead>
 	<tbody>
 		<?php foreach ($datapesanan as $key => $value): ?>
 			<tr>
 			<td><?php echo $value['no_pesanan']; ?></td>
 			<td><?php echo $value['tgl_pembelian']; ?></td>
 			<td><?php echo $value['no_meja_pelanggan']; ?></td>
 			<td><?php echo $value['status_pesanan']; ?></td>
 			<td>Rp. <?php echo number_format($value['total_pembayaran']); ?></td>
 			<td>
 				<a href="index.php?halaman=nota&id=<?php echo $value['id_pesanan']; ?>" class="btn btn-info btn-sm">Nota</a>
 				<a href="index.php?halaman=pembayaran&id=<?php echo $value['id_pesanan']; ?>" class="btn btn-success btn-sm">Pembayaran</a>
 			</td>
 		</tr>
 		<?php endforeach ?>
 	</tbody>
 </table>