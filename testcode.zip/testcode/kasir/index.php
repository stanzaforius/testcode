<?php 
include '../config/class.php';
 ?>
<?php 
// login itu menyimpan akun admin di session, bila blom login, maka blom ada session

// jika blom ada session admin(blum login, maka dilarikan ke login.php)
if (!isset($_SESSION['kasir'])) 
{
	echo "<script>alert('anda harus login');</script>";
	echo "<script>location='login.php';</script>";
	exit();
}

 ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Shouganai Kasir</title>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<link rel="stylesheet"  href="fontawesome-free-5.0.6/web-fonts-with-css/css/fontawesome-all.min.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet"  href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
		<link rel="stylesheet"  href="css/sendiri.css">
 </head>
	<body>
	
		<div id="wrapper">
			<nav class="navbar navbar-default">
				<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".sidebar-collapse" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="#">Shoganai</a>
		</div>
			</nav>
			<nav class="navbar-default navbar-side">

				<div class="sidebar-collapse">
					<div class="user">
					<img src="img/user.png">
					<h3>Shouganai</h3>
					<p>Kasir</p>
				</div>
					<ul class="nav" id="main-menu">
						<li><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
						<li><a href="index.php?halaman=kategori">Kategori</a></li>
						<li><a href="index.php?halaman=menu">Menu</a></li>
						<li><a href="index.php?halaman=pelayan"><i class="fa fa-user"></i> Pelayan</a></li>
						<li><a href="index.php?halaman=pesanan"><i class="fa fa-cube"></i> Pesanan</a></li>
						<li><a href="index.php?halaman=logout"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
					</ul>
				</div>
			</nav>
			<div id="page-wrapper">
				<div id="page-inner">
					<?php 
					// jika tidak ada parameter halaman (index.php aja)
					if(!isset($_GET['halaman']))
					{
						// panggil file home.php
						include 'home.php';
					}

					// selain itu berarti ada parameter halaman
					else
					{

						// selainitu, jika halaman sama dengan kategori, maka panggil dari folder kategori/tampilkategori.php
						if ($_GET['halaman']=="kategori") 
						{
							include 'kategori/tampilkategori.php';
						}
						elseif ($_GET['halaman']=="tambahkategori") 
						{
							include 'kategori/tambahkategori.php';
						}
						elseif ($_GET['halaman']=="hapuskategori") 
						{
							include 'kategori/hapuskategori.php';
						}
						elseif ($_GET['halaman']=="ubahkategori") 
						{
							include 'kategori/ubahkategori.php';
						}
						elseif ($_GET['halaman']=="menu") 
						{
							include 'menu/tampilmenu.php';
						}
						elseif ($_GET['halaman']=="tambahmenu") 
						{
							include 'menu/tambahmenu.php';
						}
						elseif ($_GET['halaman']=="hapusmenu")
						{
							include 'menu/hapusmenu.php';
						}
						elseif ($_GET['halaman']=="ubahmenu") 
						{
							include 'menu/ubahmenu.php';
						}
						elseif ($_GET['halaman']=="pelayan") 
						{
							include 'pelayan/tampilpelayan.php';
						}
						elseif ($_GET['halaman']=="tambahpelayan") 
						{
							include 'pelayan/tambahpelayan.php';
						}
						elseif ($_GET['halaman']=="hapuspelayan") 
						{
							include 'pelayan/hapuspelayan.php';
						}
						elseif ($_GET['halaman']=="ubahpelayan") 
						{
							include 'pelayan/ubahpelayan.php';
						}
						elseif ($_GET['halaman']=="pesanan") 
						{
							include 'pesanan/tampilpesanan.php';
						}
						elseif ($_GET['halaman']=="nota") 
						{
							include 'pesanan/nota.php';
						}
						elseif ($_GET['halaman']=="pembayaran") 
						{
							include 'pesanan/pembayaran.php';
						}
						elseif ($_GET['halaman']=="lunas") 
						{
							include 'pesanan/lunas.php';
						}
						elseif ($_GET['halaman']=="logout") 
						{
							include 'logout.php';
						}
					}

					?>					
				</div>
			</div>
		</div>

		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
		<script src="js/sendiri.js"></script>

		<script>
			$(document).ready(function() {
    	$('#thetables').DataTable();
			} );
		</script>

		<script src="ckeditor/ckeditor.js"></script>
		<script>
			CKEDITOR.replace('theeditor');
		</script>
	</body>
</html>