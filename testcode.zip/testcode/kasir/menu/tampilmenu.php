<h2>Data Menu</h2>
<?php 
$datamenu  = $menu->tampil_menu();
 ?>

 <table class="table table-bordered">
 	<thead>
 		<tr>
 			<th>No</th>
 			<th>Nama Kategori</th>
 			<th>Nama Menu</th>
 			<th>Harga</th>
 			<th>Gambar</th>
 			<th>Status</th>
 			<th>Aksi</th>
 		</tr>
 	</thead>
 	<tbody>
 		<?php foreach ($datamenu as $key => $value): ?>
 		<tr>
 			<td><?php echo $key+1 ?></td>
 			<td><?php echo $value['nama_kategori']; ?></td>
 			<td><?php echo $value['nama_menu']; ?></td>
 			<td><?php echo $value['harga_menu']; ?></td>
 			<td><img src="gambar_menu/<?php echo $value["gambar_menu"]; ?>" width="150"></td>
 			<td><?php echo $value['status']; ?></td>
 			<td>
 				<a href="" class="btn btn-primary">Detail</a>
 				<a href="index.php?halaman=ubahmenu&id=<?php echo $value['id_menu']; ?>" class="btn btn-warning">Ubah</a>
 				<a href="index.php?halaman=hapusmenu&id=<?php echo $value['id_menu']; ?>" class="btn btn-danger">Hapus</a>
 			</td>
 		</tr>
 		<?php endforeach ?>
 	</tbody>
 </table>

 <a href="index.php?halaman=tambahmenu" class="btn btn-primary">Tambah Data</a>