<h2>Ubah Produk</h2>
<?php 

$idmenu = $_GET['id'];

// obyek produk akses fungsi ambil_produk
$detailmenu = $menu->ambil_menu($idmenu);

// obyek kategori akses fungsi tampil_kategori
$datakategori = $kategori->tampil_kategori();
 ?>
 <pre><?php print_r($detailmenu); ?></pre>

 <form method="post" enctype="multipart/form-data" class="form-horizontal">
	<div class="form-group">
		<label class="col-md-2 control-label">Kategori</label>
		<div class="col-md-8">
			<select class="form-control" name="id_kategori">
				<option>Pilih Kategori</option>
				<?php foreach ($datakategori as $key => $value): ?>
				<option value="<?php echo $value['id_kategori']; ?>"  <?php if ($value["id_kategori"]==$detailmenu['id_kategori']) 
				{
					echo "selected";
				} ?>><?php echo $value['nama_kategori']; ?></option>
				<?php endforeach ?>
			</select>
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Nama Menu</label>
		<div class="col-md-8">
			<input type="text" name="nama" class="form-control" value="<?php echo $detailmenu['nama_menu']; ?>">
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Harga</label>
		<div class="col-md-8">
			<input type="number" name="harga" class="form-control" value="<?php echo $detailmenu['harga_menu']; ?>">
		</div>
	</div>
	<div class="form-group">
		<div class="col-md-8 col-md-offset-2">
			<img src="gambar_menu/<?php echo $detailmenu['gambar_menu']; ?>" width="150">
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Gambar</label>
		<div class="col-md-8">
			<input type="file" name="gambar" class="form-control">
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Status</label>
		<div class="col-md-8">
			<select class="form-control" name="status">
				<option>Ready</option>
				<option>Tidak Ready</option>
			</select>
		</div>
	</div>
	<div class="col-md-8 col-md-offset-2">
		<button class="btn btn-primary" name="simpan">Simpan</button>
	</div>
</form>

<?php 
// jika ada tombol simpan, maka
if (isset($_POST['simpan'])) 
{
	// obyek produk akses fungsi ubah_produk(inputan dari formulir)
	$menu->ubah_menu($_POST['id_kategori'],$_POST['nama'],$_POST['harga'],$_FILES['gambar'],$_POST['status'],$idmenu);

	echo "<script>alert('data berhasil diubah');</script>";
	echo "<script>location='index.php?halaman=menu';</script>";

}
 ?>