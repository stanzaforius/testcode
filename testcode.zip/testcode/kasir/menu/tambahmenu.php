<?php 
// obyek kategori akses fungsi tampil kategori
$datakategori = $kategori->tampil_kategori();

 ?>

<h2>Tambah Data</h2>
<form method="post" enctype="multipart/form-data" class="form-horizontal">
	<div class="form-group">
		<label class="col-md-2 control-label">Kategori</label>
		<div class="col-md-8">
			<select class="form-control" name="id_kategori">
				<option>Pilih Kategori</option>
				<?php foreach ($datakategori as $key => $value): ?>
				<option value="<?php echo $value['id_kategori']; ?>"><?php echo $value['nama_kategori']; ?></option>
				<?php endforeach ?>
			</select>
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Nama Menu</label>
		<div class="col-md-8">
			<input type="text" name="nama" class="form-control">
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Harga</label>
		<div class="col-md-8">
			<input type="number" name="harga" class="form-control">
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Gambar</label>
		<div class="col-md-8">
			<input type="file" name="gambar" class="form-control">
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-2 control-label">Status</label>
		<div class="col-md-8">
			<select class="form-control" name="status">
				<option>Ready</option>
				<option>Tidak Ready</option>
			</select>
		</div>
	</div>
	<div class="col-md-8 col-md-offset-2">
		<button class="btn btn-primary" name="simpan">Simpan</button>
	</div>
</form>

<?php 
// jika ada tombol simpan, maka
if (isset($_POST['simpan'])) 
{
	// obyek produk akses fungsi simpan_produk(inputan dari formulir)
	$menu->simpan_menu($_POST['id_kategori'],$_POST['nama'],$_POST['harga'],$_FILES['gambar'],$_POST['status']);

	echo "<script>alert('menu tersimpan');</script>";
	echo "<script>location='index.php?halaman=menu';</script>";

}
 ?>