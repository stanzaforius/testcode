<?php 
$idmenu = $_GET['id'];

$menu->hapus_menu($idmenu);
echo "<script>alert('data menu terhapus');</script>";
echo "<script>location='index.php?halaman=menu';</script>";

 ?>