<?php 
include 'config/class.php';

$datamenu = $menu->tampil_menu_terbaru(0,8);
// echo "<pre>";
// print_r($dataproduk);
// echo "</pre>";
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Shoganai Resto</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>
	
	<?php include 'header.php'; ?>
	<?php include 'menu.php'; ?>
<section class="hero">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="owl-carousel" id="owl-mainslider">
						<div>
							<img src="img/slider/nasigoreng.png" alt="" class="img-responsive">
						</div>
						<div>
							<img src="img/slider/slider4.jpg" alt="">
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<?php include 'sidebar.php'; ?>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container">
			<div class="section-title">
				<div class="row">
					<div class="col-md-10 col-xs-10">
						<h3>Menu Terbaru</h3>
					</div>
					<div class="col-md-2 col-xs-2">
						<div class="text-right" id="customNavProduct"></div>
					</div>
				</div>
			</div>
			<div class="owl-carousel" id="owl-product">
				<?php foreach ($datamenu as $key => $value): ?>
					
				
				<div>
					<div class="product-image">
						<img src="kasir/gambar_menu/<?php echo $value['gambar_menu']; ?>" alt="">
					</div>
					<h3 class="product-title"><a href=""><?php echo $value['nama_menu']; ?></a></h3>
					<h5 class="product-price">Rp. <?php echo number_format($value['harga_menu']); ?></h5>
					<a href="detail.php?id=<?php echo $value['id_menu']; ?>" class="btn btn-default">Detail</a>
					<a href="belimenu.php?id=<?php echo $value["id_menu"]; ?>" class="btn btn-primary">Beli</a>

				</div>
				<?php endforeach ?>
			</div>
		</div>
	</section>

	



	<script src="js/jquery-1.11.3-jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="OwlCarousel2-2.2.1/dist/owl.carousel.min.js"></script>
	<script>
		$(document).ready(function(){
			$("#owl-mainslider").owlCarousel({
				items:1,
				loop:true,
			});
		});
		$(document).ready(function(){
			$("#owl-product").owlCarousel({
				items:5,
				loop:true,
				margin:10,
				nav:true,
				navContainer:'#customNavProduct',
				navText: ["<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-left'></span></a>","<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-right'></span></a>"],
				responsive:{
					0:{
						items:2
					},
					600:{
						items:3
					},
					1000:{
						items:5
					}
				}

			});
		});
	</script>
</body>
</html>