<?php 
session_start();
// membuat koneksi ke db dengan mysqli
$mysqli = new mysqli("localhost","root","","testcode");

class pelayan
{
	public $koneksi;

	function __construct($mysqli)
	{
		$this->koneksi = $mysqli;
	}

	function tampil_pelayan()
	{
		$ambildata = $this->koneksi->query("SELECT * FROM pelayan");
		while ($pecahdata = $ambildata->fetch_assoc())
		{
			$semuadata[] = $pecahdata;
		}
		return $semuadata;
	}
	function login_pelayan($username,$password)
	{
		// enkripsi dulu passwordnya
		$enpass = sha1($password);

		//mengakses tabel pelanggan untuk mengecek pelanggan yang emailnya itu dan password itu
		$ambil = $this->koneksi->query("SELECT * FROM pelayan WHERE username ='$username' 
			AND password='$enpass'");

		 //menghitung yang cocok lewat attribut num_rows
		 $yangcocok = $ambil->num_rows;

		 if ($yangcocok==0) 
		 {
		  	return "gagal";
		 } 
		  else
		  {
		  	// mendapatkan data dalam bentuk array
		  	$datayglogin = $ambil->fetch_assoc();
		  	// simpan data yang login di session
		  	$_SESSION['pelayan'] = $datayglogin;

		  	return "sukses";
		  }
	}
}
class kategori
{
	public $koneksi;

	function __construct($mysqli)
	{
		$this->koneksi  = $mysqli;
	}
	function tampil_kategori()
	{
		// mengambil data dari tabel kategori
		$ambil = $this->koneksi->query("SELECT * FROM kategori");
		// 2. pecah ke array
		while($pecah = $ambil->fetch_assoc())
		{
			$semua[] = $pecah;
		}
		return $semua;
	}
}

class kasir
{
	public $koneksi;

	function __construct($mysqli)
	{
		$this->koneksi  = $mysqli;
	}

	function login_kasir($username,$password)
	{
		// enkripsi password dgn sha1
		$pass = sha1($password);

		// 1. mengambil data admin yang cocok dengan email itu dan password itu
		$ambil = $this->koneksi->query("SELECT * FROM kasir WHERE username='$username' AND password='$pass'");
		// 2.menghitung data yang cocok
		$yangcocok = $ambil->num_rows;
		// 3. bila yangcocok bernilai 1(ada 1 akun yg benar), maka login sukses
		if ($yangcocok==1) 
		{
			// 3a.memecah akun ke array
			$akun = $ambil->fetch_assoc();
			// 3b.menyimpan akun ke session['admin']
			$_SESSION['kasir'] = $akun;
			return "sukses";
		}
		// 4. selain itu (0 akun yg cocok), maka gagal
		else
		{
			return "gagal";
		}
	}

}

class menu
{
	public $koneksi;
	function __construct($mysqli)
	{
		$this->koneksi = $mysqli;
	}
	function tampil_menu()
	{
		// akses query ke table produk
		$ambil = $this->koneksi->query("SELECT * FROM menu JOIN kategori 
			ON menu.id_kategori = kategori.id_kategori");
		while($pecah = $ambil->fetch_assoc())
		{
			$semuadata[] = $pecah;
		}
		return $semuadata;
	}

	function simpan_menu($id_kategori,$nama,$harga,$gambar,$status)
	{
		// mengambil namagambar
		$namagambar = $gambar['name'];

		// mengambil lokasigambar
		$lokasigambar = $gambar['tmp_name'];

		$waktu = date("Y_m_d_H_i_s");
		$namafix = $waktu."_".$namagambar;

		// mengupload dari lokasi ke ..//gambar_menu/$namagambar
		move_uploaded_file($lokasigambar, "../kasir/gambar_menu/$namafix");
		// query simpan ke database
		$this->koneksi->query("INSERT INTO menu(id_kategori,nama_menu,harga_menu,gambar_menu,status) VALUES('$id_kategori','$nama','$harga','$namafix','$status')");
	}
	function ambil_menu($idmenu)
	{
		$ambil = $this->koneksi->query("SELECT * FROM menu JOIN kategori ON menu.id_kategori = kategori.id_kategori where id_menu = '$idmenu'");
		$pecah = $ambil->fetch_assoc();
		return $pecah;
	}
	function hapus_menu($idmenu)
	{
		// $datamenu = $this->ambil_menu($idmenu);

		// menghapus data pelanggan dari data base
		$this->koneksi->query("DELETE FROM menu WHERE id_menu='$idmenu'");
	}

	function ubah_menu($id_kategori,$nama,$harga,$gambar,$status,$idmenu)
	{
		
		// 1.mengambil namagambar
		$namagambar = $gambar['name'];

		// 2.mengambil lokasigambar
		$lokasigambar = $gambar['tmp_name'];

		// 3. jika lokasigambar tidak kosong(gambar diganti),maka
		if (!empty($lokasigambar)) 
		{
			// mengakses fungsi ambil_menu
			$datamenu = $this->ambil_menu($idmenu);
			// mendapatkan nama gambar yang mau dihapus
			$gambarhapus = $datamenu['gambar_menu'];
			// jika file ada maka foto dihapus
			if (file_exists("../kasir/gambar_menu/$gambarhapus")) 
			{
				unlink("../kasir/gambar_menu/$gambarhapus");
			}
			// mengupload foto yg baru
			move_uploaded_file($lokasigambar, "../kasir/gambar_menu/$namagambar");
			// query ubah data
			$this->koneksi->query("UPDATE menu SET id_kategori='$id_kategori',nama_menu='$nama',harga_menu='$harga',gambar_menu='$namagambar',status='$status' WHERE id_menu='$idmenu'");
		}
			else
		{
			$this->koneksi->query("UPDATE menu SET id_kategori='$id_kategori',nama_menu='$nama',harga_menu='$harga', status='$status' WHERE id_menu='$idmenu'");
		}
	}

	function tampil_menu_terbaru($posisi=0,$batas=8)
	{
		$semuadata = array();
		$ambil = $this->koneksi->query("SELECT * FROM menu JOIN kategori ON menu.id_kategori=kategori.id_kategori WHERE status='ready' ORDER BY menu.id_menu DESC LIMIT $posisi,$batas");
		while($pecah = $ambil->fetch_assoc())
		{
			$semuadata[] = $pecah;
		}
		return $semuadata;
	}
	function total_data()
	{
		$ambil = $this->koneksi->query("SELECT*FROM menu");
		$total = $ambil->num_rows;
		return $total;
	}
}

class pesanan
{
	public $koneksi;

	function __construct($mysqli)
	{
		$this->koneksi = $mysqli;
	}
	function tampil_pesanan()
	{
		$ambil = $this->koneksi->query("SELECT * FROM pesanan");
		while($pecah = $ambil->fetch_assoc())
		{
			$semuadata[] = $pecah;
		}
		return $semuadata;
	}
	function masukan_basket($jumlah,$id_menu)
	{
		// jika sudah ada produk itu di session basket
		if (isset($_SESSION["basket"][$id_menu])) 
		{
			$_SESSION["basket"][$id_menu] += $jumlah;
		}
		else
		{
			$_SESSION["basket"][$id_menu] = $jumlah;	
		}
		
	}
	function tampil_basket()
	{
		// jika ada basket belanja
		if (isset($_SESSION["basket"])) 
		{
			$semuadata = array();
			// perulangkan array pada session basket
			foreach ($_SESSION["basket"] as $id_menu => $jumlah) 
			{
				// mendapatkan data produk berdasarkan id_produk yang sedang diperulangkan
				$ambil = $this->koneksi->query("SELECT * FROM menu WHERE id_menu='$id_menu'");
				$pecahmenu = $ambil->fetch_assoc();
				// masukkan jumlah ke array pecahproduk
				$pecahmenu["jumlah"] = $jumlah;
				// subharga (harga x jumlah beli)
				$pecahmenu["subharga"] = $pecahmenu["harga_menu"] * $jumlah;
				$semuadata[] = $pecahmenu;


			}
			return $semuadata;
		}
		else
		{
			return array();
		}
	}
	function tampil_pesanan_pelayan($id_pelayan)
	{
		$semuadata = array();
		$ambil = $this->koneksi->query("SELECT*FROM pesanan WHERE id_pelayan= '$id_pelayan'");
		while($pecah = $ambil->fetch_assoc())
		{
			$semuadata[] = $pecah;
		}
		return $semuadata;	
	}
	function simpan_pesanan($no_pesanan,$no_meja_pelanggan,$tgl_pembelian,$status,$total_pembayaran)
	{
		// mendapatkan id_pelayan yg login
		$id_pelayan = $_SESSION["pelayan"]["id_pelayan"];
		$this->koneksi->query("INSERT INTO pesanan(id_pelayan,no_pesanan,no_meja_pelanggan,tgl_pembelian,status_pesanan,total_pembayaran) VALUES('$id_pelayan','$no_pesanan','$no_meja_pelanggan','$tgl_pembelian','$status','$total_pembayaran')");

		// mendapatkan id_pesanan yang barusan terjadi
		$id_pesanan = $this->koneksi->insert_id;

		// simpan data (pesanan yg dibeli) ke tabel pesanandetail
		// menggunakan bantuan fungsi tampil_basket()
		$databasket = $this->tampil_basket();
		foreach ($databasket as $key => $permenu)
		{
			$namamenu = $permenu['nama_menu'];
			$hargamenu = $permenu['harga_menu'];
			$jumlah = $permenu['jumlah'];
			$subhargamenu = $permenu['subharga'];

			$this->koneksi->query("INSERT INTO pesanandetail(id_pesanan,nama_menu,harga_menu,jumlah,subharga_menu) VALUES('$id_pesanan','$namamenu','$hargamenu','$jumlah','$subhargamenu')");
		}
		// kosongkan keranjang belanja
		unset($_SESSION["basket"]);

		// outputkan id_pesanan sebagai idnota
		return $id_pesanan;
	}

	function tampil_menu_pesanan($id_pesanan)
	{
		// menampilkan data dari tabel pembelian detail yg id_pembeliannya ada diurl
		$ambil = $this->koneksi->query("SELECT * FROM pesanandetail WHERE id_pesanan='$id_pesanan'");
		while($pecah = $ambil->fetch_assoc())
		{
			$semuadata[] = $pecah;
		}
		return $semuadata;
		
	}
	function ambil_pesanan($id_pesanan)
	{
		$ambil = $this->koneksi->query("SELECT * FROM pesanan JOIN pelayan ON pesanan.id_pelayan = pelayan.id_pelayan where pesanan.id_pesanan = '$id_pesanan'");
		$pecah = $ambil->fetch_assoc();
		return $pecah;
	}
}

$pelayan = new pelayan($mysqli);
$kategori = new kategori($mysqli); 
$kasir = new kasir($mysqli);
$menu = new menu($mysqli);
$pesanan = new pesanan($mysqli);

?>