<?php 
include 'config/class.php';


$id_menu = $_GET["id"];

// membuat default jumlah yg dibeli
$jumlah = 1;

// obyek pembelian menjalankan fungsi masukan _basket(jumlah,id_produk)
$pesanan->masukan_basket($jumlah,$id_menu);

echo "<script>alert('menu telah dimasukkan ke basket belanja');</script>";
echo "<script>location='basket.php';</script>";

 ?>