<?php
$datakategori = $kategori->tampil_kategori();

// echo "<pre>";
// print_r($datakategori);
// echo "</pre>";
?>

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title">Kategori</h3>
	</div>
	<div class="list-group">
		<?php foreach ($datakategori as $key => $value): ?>
			<a href="kategori.php?id=<?php echo $value['id_kategori']; ?>" class="list-group-item">
				<?php echo $value['nama_kategori']; ?>
			</a>
		<?php endforeach ?>
	</div>
</div>