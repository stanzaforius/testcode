<?php 
include 'config/class.php';
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Shoganai Resto</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>
	
	<?php include 'header.php'; ?>
	<?php include 'menu.php'; ?>
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="section-title">
						<h3>Login Pelayan</h3>
					</div>
					<form method="post">
							<div class="form-group">
								<label>Username Pelayan</label>
								<input type="text" class="form-control" name="username">
							</div>	
							<div class="form-group">
								<label>Password</label>
								<input type="text" class="form-control" name="password">
							</div>
							<button class="btn btn-primary" name="login">Login</button>
						</form>
						<?php 
						// jika ada tombol login,maka
						if (isset($_POST["login"])) 
						{
							// obyek pelayan menjalankan fungsi login_pelayan(username dan password dari formulir)
							$hasil = $pelayan->login_pelayan($_POST["username"],$_POST["password"]);
							// jika hasil sama dengan sukses
							if ($hasil=="sukses") 
							{
								echo "<script>alert('login sukses');</script>";
								echo "<script>location='member.php';</script>";
							}
							else
							{
								echo "<script>alert('login gagal');</script>";
								echo "<script>location='login.php';</script>";
							}
						}
						 ?>

				</div>
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-body">
							Daftar menjadi member kami dan mulailah memesan makanan kami, lebih banyak menu tersedia untuk Anda.
						</div>
						<div class="panel-footer">
							<a href="">Daftar</a>
						</div>
					</div>
				</div>
			</div>	
		</div>
	</section>
	
	<!-- <?php //include 'footer.php'; ?> -->



	<script src="js/jquery-1.11.3-jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="OwlCarousel2-2.2.1/dist/owl.carousel.min.js"></script>
	
</body>
</html>