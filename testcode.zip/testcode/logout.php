<?php 
include 'config/class.php';

// menghapus data akun yang dibuat saat orang login

// menghapus session pelanggan
// unset($_SESSION['pelanggan']);

// menghancurkan semua session
session_destroy();
echo "<script>alert('anda telah logout');</script>";
echo "<script>location='index.php';</script>";




 ?>