<?php 
include 'config/class.php';
 ?>

 <?php 
// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";

// jika tidak ada session pelanggan (belum login), maka larikan ke login.php
if (!isset($_SESSION["pelayan"])) 
{
	echo "<script>alert('anda belom login');</script>";
	echo "<script>location='login.php'</script>";
}

// mendapatkan id_pelanggan yg login
$id_pelayan = $_SESSION["pelayan"]["id_pelayan"];
// gunakan obyek pembelian menjalankan fungsi tampil_pembelian_pelanggan(kasih idnya)
$datapesanan = $pesanan->tampil_pesanan_pelayan($id_pelayan);
  ?>
  <!-- <pre><?php print_r($datapembelian); ?></pre> -->

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Shoganai Resto</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>
	
	<?php include 'header.php'; ?>
	<?php include 'menu.php'; ?>
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="thumbnail">
						<img src="img/member/wanita4.jpeg" alt="" class="img-responsive img-circle">
					</div>
						<ul class="list-group">
							<li class="list-group-item"><?php echo $_SESSION["pelayan"]["nama_pelayan"]; ?></li>
							<li class="list-group-item"><?php echo $_SESSION["pelayan"]["username"]; ?></li>
						</ul>
				</div>
				<div class="col-md-9">
					<div class="section-title">
						<h3>Riwayat Pesanan</h3>
					</div>
					<table class="table table-bordered table-hover table-striped">
						<thead>
							<tr>
								<th>No Pesanan</th>
								<th>Tanggal</th>
								<th>Status</th>
								<th>Total Bayar</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($datapesanan as $key => $value): ?>
								
							
							<tr>
								<td><?php echo $value['no_pesanan'] ?></td>
								<td><?php echo $value['tgl_pembelian']; ?></td>
								<td><?php echo $value['status_pesanan']; ?></td>
								<td>Rp. <?php echo number_format($value['total_pembayaran']); ?></td>
								<td>
									<a href="nota.php?id=<?php echo $value['id_pesanan']; ?>" class="btn btn-info btn-xs">Nota</a>
									<a href="pembayaran.php?id=<?php echo $value['id_pesanan']; ?>" class="btn btn-success btn-xs">Pembayaran</a>
								</td>
							</tr>
							<?php endforeach ?>
						</tbody>
					</table>
				</div>
			</div>	
		</div>
	</section>
	
	<?php include 'footer.php'; ?>



	<script src="js/jquery-1.11.3-jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="OwlCarousel2-2.2.1/dist/owl.carousel.min.js"></script>
	
</body>
</html>