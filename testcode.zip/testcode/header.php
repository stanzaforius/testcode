<header class="header">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="logo">
						<img src="img/logo.png" alt="" class="img-responsive">
					</div>
				</div>
				<div class="col-md-6">
					<div class="search">
						<form method="post" action="pencarian.php">
							<div class="form-group">
								<div class="input-group">
									<input type="text" class="form-control" name="keyword">
									<span class="input-group-btn">
										<button class="btn btn-default">Cari</button>
									</span>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-3">
					<div class="keranjang text-right">
						<div class="btn-group" role="group">
							<a href="#" class="btn btn-default">
								<span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span>
							</a>
							<a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Basket
								<span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
								<?php $datker = $pesanan->tampil_basket(); ?>
								<?php foreach ($datker as $key => $value): ?>
									
								
								<li><a href="detail.php?id=<?php echo $value["id_menu"]; ?>"><?php echo $value["nama_menu"]; ?></a></li>
								
								<?php endforeach ?>
								<li class="divider"></li>
								<li><a href="">Lihat Keranjang</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>