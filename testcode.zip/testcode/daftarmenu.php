<?php 
	include 'config/class.php';
 ?>
<?php 
// menentukan page berapa saya ini
// jk di url ada page
if (isset($_GET["page"]) AND !empty($_GET["page"])) 
{
	$page = $_GET["page"];
}
else
{
	$page=1;
}
// menentukan batas
$batas= 3;
// menentukan posisimulai
$posisimulai = ($page-1)*$batas;




$datamenu = $menu->tampil_menu_terbaru($posisimulai,$batas);

// echo "<pre>";
// print_r($dataproduk);
// echo "</pre>";
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>fitmart - belanja fashion apasaja</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>
	
	<?php include 'header.php'; ?>
	<?php include 'menu.php'; ?>
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="section-title">
						<h3>Daftar Menu</h3>
					</div>

					<!-- mulai produk -->
					
						
					
					<div class="row">
						<?php foreach ($datamenu as $key => $value): ?>
						<div class="col-md-4"> 

							<div class="product-image">
								<img src="kasir/gambar_menu/<?php echo $value['gambar_menu']; ?>" alt="" class="img-responsive">
							</div>
							<h3 class="product-title">
								<a href=""><?php echo $value['nama_menu']; ?></a>
							</h3>
							<h5 class="product-price">Rp. <?php echo number_format($value['harga_menu']); ?></h5>
							<a href="" class="btn btn-default">Detail</a>
							<a href="" class="btn btn-primary">Beli</a>
						</div>
					<?php endforeach ?>
					</div>
					
					<!-- akhir produk -->
					<!-- paging -->
					<?php 
					$total_data = $menu->total_data();//mendapatkan total_data()
					$batas = 3;
					$totalpage = $total_data/$batas;//mendapatkan totalpage
					$totalpage = ceil($totalpage);

					 ?>
					 <ul class="pagination">
					 	<?php 
					 	$i = 1;
					 	while ($i <= $totalpage) 
					 	{
					 		if ($i==$page) 
					 		{
					 			$oke = "active";
					 		}
					 		else
					 		{
					 			$oke = "";
					 		}
					 		echo "<li class='$oke'><a href='daftarmenu.php?page=$i'>$i</a></li>";
					 		$i++;
					 	}
						?>
					</ul>
				</div>
				<div class="col-md-3">
					<?php include 'sidebar.php'; ?>
				</div>
			</div>
		</div>
	</section>
	
	<?php include 'footer.php'; ?>



	<script src="js/jquery-1.11.3-jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="OwlCarousel2-2.2.1/dist/owl.carousel.min.js"></script>
	<script>
		$(document).ready(function(){
			$("#owl-product").owlCarousel({
				items:5,
				loop:true,
				margin:10,
				nav:true,
				navContainer:'#customNavProduct',
				navText: ["<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-left'></span></a>","<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-right'></span></a>"],
				responsive:{
					0:{
						items:2
					},
					600:{
						items:3
					},
					1000:{
						items:5
					}
				}

			});
		});
	</script>
	
</body>
</html>