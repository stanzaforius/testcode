<?php 
include 'config/class.php';
// mendapatkan id_menu dari url
$id_menu =  $_GET['id'];

// buang data dari variabel pakai unset
// hapus dari session basket
unset($_SESSION["basket"][$id_menu]);

echo "<script>alert('menu telah dihapus dari basket belanja');</script>";
echo "<script>location='basket.php';</script>";

 ?>