<?php 
include 'config/class.php';
 ?>
 <?php 
	$id_pesanan = $_GET['id'];

// obyek pembelian menjalankan fungsi tampil_pembelian_produk(id pembelian dari url)
$datamenupesanan = $pesanan->tampil_menu_pesanan($id_pesanan);

// obyek pembelian menjalankan method ambil_pembelian(id pembelian dari url)
$detailpesanan = $pesanan->ambil_pesanan($id_pesanan);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Shoganai Resto</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>
	
	<?php include 'header.php'; ?>

	<?php include 'menu.php'; ?>
	<section class="content">
		<div class="container">
			<div class="section-title">
				<h2>Nota Pesanan: #<?php echo $detailpesanan["id_pesanan"]; ?></h2>
			</div>
<hr>



<div class="row">
	<div class="col-md-4">
		<h3>Pesanan</h3>
		<p>No Pesanan: <?php echo $detailpesanan['no_pesanan']; ?></p>
		<p>Tanggal: <?php echo $detailpesanan['tgl_pembelian']; ?></p>
		<p>Status: <span class="btn btn-danger btn-xs"><?php echo $detailpesanan['status_pesanan']; ?></span></p>
	</div>
	<div class="col-md-4">
		<h3>Pelanggan</h3>
		<p> No Meja Pelanggan: <?php echo $detailpesanan['no_meja_pelanggan']; ?></p>
		<p>Nama Pelayan: <?php echo $detailpesanan['nama_pelayan']; ?></p>
	</div>
</div>



						<table class="table table-bordered table-hover table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Menu</th>
								<th>Harga</th>
								<th>Jumlah</th>
								<th>Subtotal</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							
							 <!-- <pre><?php print_r($databasket); ?></pre> -->
							<?php $totalbelanja = 0; ?>
							<?php foreach ($datamenupesanan as $key => $value): ?>
							<?php $totalbelanja+=$value['subharga_menu']; ?>
							<tr>
								<td><?php echo $key+1 ?></td>
								<td><?php echo $value['nama_menu']; ?></td>
								<td>Rp. <?php echo number_format($value['harga_menu']); ?></td>
								<td><?php echo $value['jumlah']; ?> Item</td>
								<td>Rp. <?php echo number_format($value['subharga_menu']); ?></td>
								<td>
									<a href="hapusbasket.php?id=<?php echo $value['id_menu']; ?>" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-remove"></i></a>

								</td>
							</tr>
							<?php endforeach ?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="4">Total Belanja</th>
								<td>Rp. <?php echo number_format($totalbelanja); ?></td>
							</tr>
						</tfoot>
					</table>
		</div>
			</section>

			<?php include 'footer.php'; ?>



			<script src="js/jquery-1.11.3-jquery.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="OwlCarousel2-2.2.1/dist/owl.carousel.min.js"></script>

		</body>
		</html>