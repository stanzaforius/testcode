<?php include 'config/class.php'; ?>
<?php 
// jika belom login
if (!isset($_SESSION["pelayan"]) OR empty($_SESSION["pelayan"]) ) 
{
	echo "<script>alert('silahkan login dahulu');</script>";
	echo "<script>location='login.php';</script>";
}
// jika belum belanja (atau keranjang belanjan kosong)
if (!isset($_SESSION['basket']) OR empty($_SESSION['basket'])) 
{
	echo "<script>alert('silahkan pesan dahulu');</script>";
	echo "<script>location='index.php';</script>";
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Shoganai Market</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>


<?php include 'header.php'; ?>
<?php include 'menu.php'; ?>
<div class="container">
	<h3>Data Pesanan</h3>
	<table class="table table-bordered table-hover table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Menu</th>
								<th>Harga</th>
								<th>Jumlah</th>
								<th>Subtotal</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								// obyek pembelian menjalankan fungsi tampil_keranjang()
									$databasket = $pesanan->tampil_basket();

							 ?>
							 <pre><?php print_r($databasket); ?></pre>
							<?php $totalbelanja = 0; ?>
							<?php foreach ($databasket as $key => $value): ?>
							<?php $totalbelanja+=$value['subharga']; ?>
							<tr>
								<td><?php echo $key+1 ?></td>
								<td><?php echo $value['nama_menu']; ?></td>
								<td>Rp. <?php echo number_format($value['harga_menu']); ?></td>
								<td><?php echo $value['jumlah']; ?> Item</td>
								<td>Rp. <?php echo number_format($value['subharga']); ?></td>
								<td>
									<a href="hapusbasket.php?id=<?php echo $value['id_menu']; ?>" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-remove"></i></a>

								</td>
							</tr>
							<?php endforeach ?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="4">Total Belanja</th>
								<td>Rp. <?php echo number_format($totalbelanja); ?></td>
							</tr>
						</tfoot>
					</table>

	<h3>Check Out</h3>
	<form method="post">
				<div class="form-group">
					<label>Nomor Pesanan</label>
					<input type="text" name="no_pesanan" class="form-control">
				</div>
				<div class="form-group">
					<label>No Meja Pelanggan</label>
					<input type="text" name="no_meja_pelanggan" class="form-control">
				</div>
				<div class="form-group">
					<label>Tanggal Pembelian</label>
					<input type="date" name="tgl_pembelian" class="form-control">
				</div>
				<div class="form-group">
					<label>Status Pesanan</label>
					<input type="text" name="status" class="form-control">
				</div>
				<div class="form-group">
					<label>Total Pesanan</label>
					<input type="text" class="form-control" name="total_pembayaran" value="<?php echo $totalbelanja; ?>">
				</div>
				<button class="btn btn-primary" name="checkout">Check out</button>
	</form>

	<?php 
	if (isset($_POST["checkout"])) 
	{
		$idnota = $pesanan->simpan_pesanan($_POST['no_pesanan'],$_POST['no_meja_pelanggan'],$_POST['tgl_pembelian'],$_POST['status'],$_POST['total_pembayaran']);

		// pesan dilayar
		echo "<script>alert('terimakasih telah melakukan transaksi,silahkan melakukan pembayaran sesuai dengan nota');</script>";
		echo "<script>location='nota.php?id=$idnota';</script>";
	}
	 ?>

</div>
<?php include 'footer.php'; ?>

<!-- <script src="js/jquery-3.2.1.min.js"></script> -->
<script src="//code.jquery.com/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>
