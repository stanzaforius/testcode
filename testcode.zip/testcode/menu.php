<nav class="navbar navbar-default" role="navigation">
	<div class="container">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand visible-xs" href="#">Fitmart</a>
		</div>

		<div class="collapse navbar-collapse navbar-ex1-collapse">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="daftarmenu.php">Menu</a></li>
				<li><a href="basket.php">Basket</a></li>
				<li><a href="checkout.php">Check Out</a></li>
			</ul>
			
			<ul class="nav navbar-nav navbar-right">

				<!-- jika ada session pelanggan(sudah login) -->
				<?php if (isset($_SESSION['pelayan'])): ?>
					<li><a href="member.php">Member</a></li>
					<li><a href="logout.php">Logout</a></li>
				<?php endif ?>

				<!-- jika tidak ada session pelanggan(belum login) -->
				<?php if (!isset($_SESSION['pelayan'])): ?>
					
					<li><a href="login.php">Login</a></li>
					<li><a href="daftar.php">Daftar</a></li>	
				<?php endif ?>
				
			</ul>
		</div><!-- /.navbar-collapse -->
	</div>
</nav>