<?php 
include 'config/class.php';
 ?>
 <?php 
// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";

// obyek pembelian menjalankan fungsi tampil_basket()
$databasket = $pesanan->tampil_basket();

// echo "<pre>";
// print_r($databasket);
// echo "</pre>";
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Basket Pesanan</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>
	<?php include 'header.php'; ?>
	<?php include 'menu.php'; ?>
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="section-title">
						<h3>Basket Belanja</h3>
					</div>
					<table class="table table-bordered table-hover table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Menu</th>
								<th>Harga</th>
								<th>Jumlah</th>
								<th>Subtotal</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							
							<?php $totalbelanja = 0; ?>
							<?php foreach ($databasket as $key => $value): ?>
							<?php $totalbelanja+=$value['subharga']; ?>
							<tr>
								<td><?php echo $key+1 ?></td>
								<td><?php echo $value['nama_menu']; ?></td>
								<td>Rp. <?php echo number_format($value['harga_menu']); ?></td>
								<td><?php echo $value['jumlah']; ?> Item</td>
								<td>Rp. <?php echo number_format($value['subharga']); ?></td>
								<td>
									<a href="hapusbasket.php?id=<?php echo $value['id_menu']; ?>" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-remove"></i></a>

								</td>
							</tr>
							<?php endforeach ?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="4">Total Belanja</th>
								<td>Rp. <?php echo number_format($totalbelanja); ?></td>
							</tr>
						</tfoot>
					</table>
					<a href="index.php" class="btn btn-default">Lanjutkan Memesan</a>
					<a href="checkout.php" class="btn btn-primary">Checkout</a>
				</div>
				<div class="col-md-3">
				</div>
			</div>
		</div>
	</section>
	




	<script src="js/jquery-1.11.3-jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="OwlCarousel2-2.2.1/dist/owl.carousel.min.js"></script>
	<script>
		$(document).ready(function(){
			$("#owl-product").owlCarousel({
				items:5,
				loop:true,
				margin:10,
				nav:true,
				navContainer:'#customNavProduct',
				navText: ["<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-left'></span></a>","<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-right'></span></a>"],
				responsive:{
					0:{
						items:2
					},
					600:{
						items:3
					},
					1000:{
						items:5
					}
				}

			});
		});
	</script>
	
</body>
</html>