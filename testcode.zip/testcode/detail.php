<?php 
include 'config/class.php';
 ?>
 <?php 
$id_menu = $_GET['id'];

// obyek produk menjalan fungsi ambil_produk
$detailmenu = $menu->ambil_menu($id_menu);

// echo "<pre>";
// print_r($detailmenu);
// echo "</pre>";
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Shoganai Resto</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel2-2.2.1/dist/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/warna.css">
</head>
<body>
	
	<?php include 'header.php'; ?>
	<?php include 'menu.php'; ?>
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="row">
						<div class="col-md-6">
							<div class="product-image">
								<img src="kasir/gambar_menu/<?php echo $detailmenu['gambar_menu']; ?>" alt="" class="img-responsive">
							</div>
						</div>
						<div class="col-md-6">
							<h2 class="product-title"><?php echo $detailmenu['nama_menu']; ?></h2>
							<h5 class="product-price">Rp. <?php echo number_format($detailmenu['harga_menu']); ?></h5>

							<form method="post">
								<div class="form-group">
									<div class="input-group">
										<input type="number" class="form-control" min="1" name="jumlah">
										<span class="input-group-btn">
											<button class="btn btn-primary" name="beli">Beli</button>
										</span>
									</div>
								</div>
							</form>
							<?php 
							// jika ada tombol beli
							if (isset($_POST["beli"])) 
							{
								// obyek pembelian menjalankan fungsi masukan_keranjang(jumlah dan id produk)
								$pesanan->masukan_basket($_POST["jumlah"],$id_menu);

								echo "<script>alert('menu telah dimasukkan ke basket belanja');</script>";
								echo "<script>location='basket.php';</script>";
							}

							 ?>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<?php include 'sidebar.php'; ?>
				</div>
			</div>
		</div>
	</section>

	<!-- <?php include 'footer.php'; ?> -->



	<script src="js/jquery-1.11.3-jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="OwlCarousel2-2.2.1/dist/owl.carousel.min.js"></script>
						
	<script>
		$(document).ready(function(){
			$("#owl-product").owlCarousel({
				items:5,
				loop:true,
				margin:10,
				nav:true,
				navContainer:'#customNavProduct',
				navText: ["<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-left'></span></a>","<a class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-chevron-right'></span></a>"],
				responsive:{
					0:{
						items:2
					},
					600:{
						items:3
					},
					1000:{
						items:5
					}
				}

			});
		});
	</script>
</body>
</html>